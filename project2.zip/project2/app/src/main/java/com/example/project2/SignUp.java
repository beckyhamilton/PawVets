package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SignUp extends AppCompatActivity {


    private Button backtoLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up2);


        //'Already Have an account' button takes user back to Login page
        backtoLogin = (Button) findViewById(R.id.backtoLogin_btn);
        backtoLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLoginPage();
            }
        });


    }
    public void openLoginPage() {
        Intent intent2 = new Intent(this, MainScreen.class);
        startActivity(intent2);
    }
}




