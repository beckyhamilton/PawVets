package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import info.hoang8f.widget.FButton;

public class MainActivity extends AppCompatActivity {

    //Adding Variable for Splash Screen
    private static int SPLASH_SCREEN = 5000;

    //Adding Variables for Animation
    Animation topAnim, bottomAnim, leftAnim;
    ImageView image;
    FButton SignUp;

    //Changing Layout to Full Screen
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        //Setting Animations
        topAnim = AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottomAnim = AnimationUtils.loadAnimation(this,R.anim.bottom_animation);


        //Hooks
        image = findViewById(R.id.background);
        SignUp = findViewById(R.id.SignUp);

        image.setAnimation(topAnim);
        SignUp.setAnimation(bottomAnim);

                
            }

        }

